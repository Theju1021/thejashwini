<?php
session_start();

// Check if user is logged in (you may have your own authentication mechanism)
if (!isset($_SESSION['user_id'])) {
    echo "Invalid request. Please make sure you are logged in.";
    exit;
}

// Database connection settings
$host = 'localhost';
$dbname = 'social_network';
$username = 'root';
$password = '';

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Get user_id from session
$user_id = $_SESSION['user_id'];

// Check if the POST request contains a valid post_id
if (isset($_POST['post_id'])) {
    $post_id = $_POST['post_id'];

    // Check if the post_id exists in the posts table
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE post_id = :post_id");
    $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
    $stmt->execute();
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$post) {
        echo "Invalid post ID. Please provide a valid post ID.";
        exit;
    }

    // Check if the user has already liked the post
    $stmt = $pdo->prepare("SELECT * FROM post_likes WHERE post_id = :post_id AND user_id = :user_id");
    $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $existing_like = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_like) {
        echo "You have already liked this post.";
        exit;
    }

    // Increment like_count for the post and insert into post_likes
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("UPDATE posts SET like_count = like_count + 1 WHERE post_id = :post_id");
        $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
        $stmt->execute();

        $stmt = $pdo->prepare("INSERT INTO post_likes (post_id, user_id) VALUES (:post_id, :user_id)");
        $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();

        $pdo->commit();
        echo "Like added successfully!";
    } catch (PDOException $e) {
        $pdo->rollBack();
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request. Please provide a valid post ID.";
}
?>
