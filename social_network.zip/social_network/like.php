<!DOCTYPE html>
<html>
<head>
    <title>Like Post</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <button class="likeButton" data-postid="1">Like</button>
    
    <script>
    $(document).ready(function() {
        $('.likeButton').click(function() {
            var post_id = $(this).data('postid');

            $.ajax({
                type: 'POST',
                url: 'like_post.php',
                data: { post_id: post_id },
                success: function(response) {
                    alert(response);
                },
                error: function() {
                    alert('Error occurred. Please try again.');
                }
            });
        });
    });
    </script>
</body>
</html>
